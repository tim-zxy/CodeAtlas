# Codex Handoff

## Mission

Continue the existing design without resetting it. Implement Phase 0 and Phase 0.5 as specified, use their evaluation evidence to expand and implement Phase 1, then refine Phase 2 and Phase 3 within the frozen architecture.

## First session

1. Read the documents in `README.md` order.
2. Create the monorepo structure described by the module-boundaries spec.
3. Begin `P0-W0-001` and keep Phase 0 scope strict.
4. Establish fixture discovery and architecture checks early so later work cannot bypass them.
5. Record actual progress in `CURRENT_STATUS.md`; never change readiness labels merely because work has started.

## Non-negotiable mental model

```text
Provider facts are not canonical facts.
Canonical code facts are not knowledge.
ExecutionGraph is not RuntimeFlow.
RuntimeFlow is not BusinessFlow.
Candidate is not published KnowledgeRevision.
Vector index is not canonical storage.
Freshness is not compilation currency.
```

## Phase behavior

- Phase 0: build stable contracts, storage, IPC, fixtures, and runtime skeleton. No Java parsing requirement.
- Phase 0.5: prove trustworthy, incremental Java code intelligence and code-level queries. No framework/knowledge expansion.
- Phase 1: expand the design-ready scope into reviewed tasks; implement the core product proof.
- Phase 2: complete the knowledge flywheel, hybrid retrieval, impact context, richer documents, and daemon mode.
- Phase 3: select advanced intelligence through measured utility. Do not invent a Phase 4.

## Escalation triggers

Stop and propose an ADR when implementation appears to require changing a frozen decision, producing a breaking canonical schema, changing automatic/manual update semantics, weakening security defaults, merging repository and workspace truth stores, or changing the flow hierarchy.

## Completion standard

Passing unit tests alone is insufficient. A phase completes only when its declared fixtures and quantitative gates pass, failure and recovery behavior are demonstrated, documentation is synchronized, and the acceptance checklist is signed with fresh evidence.

