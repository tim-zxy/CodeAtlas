# Design Authority

## Precedence

When documents disagree, use this order:

1. Accepted ADRs and amendments
2. `DESIGN_AUTHORITY.md`
3. Normative files in `specs/`
4. `ARCHITECTURE.md` and `PRODUCT_VISION.md`
5. `PHASE_ACCEPTANCE.md`
6. `ROADMAP.md` and `WORK_BREAKDOWN.md`
7. `CURRENT_STATUS.md`

Later dates do not override higher authority unless an ADR explicitly amends the decision.

## Frozen decisions

Changing any item below requires an ADR and synchronized updates to architecture, specs, acceptance, and traceability:

- local-first operation and no required cloud service;
- provider-independent Canonical IR;
- SQLite as canonical storage and vectors as rebuildable derived indexes;
- provider-specific and framework-specific semantics normalized below canonical contracts;
- automatic code/contract/`ExecutionGraph`/`RuntimeFlow` updates and manual semantic-knowledge publication;
- `ExecutionGraph -> RuntimeFlow -> BusinessFlow` naming and responsibility split;
- evidence, claim, candidate, and published knowledge separation;
- stable opaque knowledge identity and explicit uncertainty;
- LLM candidate generation without direct database mutation;
- application/API/service layering and domain-owned mutation;
- Rust analyzer has no SQLite ownership;
- evaluation and fixtures are implementation infrastructure;
- no automatic remote fallback when local-only or security-blocked.

## Evolvable decisions

Codex may tune these through fixtures and evaluation, recording material changes in an ADR or spec amendment:

- identity signal weights and ambiguity margins;
- FactMerger scoring and confidence aggregation;
- `RuntimeFlow` compression rules;
- knowledge projection and probe-generation policies;
- redaction patterns beyond mandatory defaults;
- provider capability routing and performance thresholds;
- semantic-task decomposition and retry counts within security/budget bounds;
- hybrid ranking weights after Phase 2 begins.

## Deferred decisions

These must not become Phase 0, 0.5, or 1 requirements without an approved roadmap amendment:

- Joern deep integration and CFG/PDG persistence;
- managed local LLM downloads;
- adaptive model/provider/retrieval routing;
- third-party plugin sandbox design;
- task session memory;
- enterprise ACLs and remote runtime;
- single-executable implementation;
- fully automatic knowledge publication.

## Codex authority

Codex shall implement the current phase, run its fixtures, update status, record design issues, refine future phases when evidence warrants it, and preserve traceability. Codex shall not silently redefine Canonical IR, lifecycle semantics, update policy, trust boundaries, or phase scope.

