# Design Traceability

| Requirement or decision | Authority | Specification | Acceptance | Initial tasks |
|---|---|---|---|---|
| Local-first, model-free core | Product Vision; ADR-001 | Runtime and Configuration; Security | P0/P1 runtime and security gates | P0-W0-003, P05-W8-001 |
| Provider-independent Canonical IR | Architecture; ADR-002 | Canonical IR; Provider SPI | P0 schema and P0.5 normalization gates | P0-W1-001..004, P05-W4-001 |
| SQLite authoritative, vector derived | ADR-003 | SQLite Schema; Evaluation | Migration gates; Phase 2 vector rebuild gate | P0-W1-005..007 |
| Automatic facts, manual knowledge | ADR-004 | Knowledge Workflow; Runtime | Phase 1 lifecycle gates | Phase 1 planning package |
| ExecutionGraph to RuntimeFlow to BusinessFlow | Architecture; ADR-005 | Canonical IR; Knowledge Workflow | Phase 1 flow/grounding gates | Phase 1 execution tasks |
| Evidence, claims, candidates, knowledge separated | ADR-006 | Canonical IR; Knowledge Workflow | P0 evidence and Phase 1 publication gates | P0-W1-004; Phase 1 knowledge tasks |
| Stable knowledge identity and conservative reconciliation | ADR-007 | Reconciliation | Phase 1 rename/revision gates | Phase 1 reconciliation tasks |
| LLM candidate only, structured output first | ADR-008 | Knowledge Workflow; Security | Phase 1 schema/grounding/security gates | Phase 1 LLM tasks |
| No automatic remote fallback | ADR-009 | Security; Runtime | Phase 1 local-only/security fixtures | Phase 1 security tasks |
| Rust analyzer streams JSONL and owns no DB | ADR-010 | Native IPC; Module Boundaries | P0 handshake/protocol and P0.5 activation gates | P0-W3-001..004 |
| Separate repo/workspace databases | ADR-011 | SQLite Schema; Module Boundaries | Migration isolation gate | P0-W1-006..007 |
| Evaluation is a first-class gate | ADR-012 | Evaluation | Every phase acceptance section | P0-W9-001..003, P05-W9-001 |
| Framework semantics below canonical layer | Architecture | Plugin SPI; Canonical IR | Phase 1 plugin fixtures | Phase 1 framework tasks |
| Cross-repo through contracts and service identity | Architecture | Provider SPI; Agent API | Phase 1 boundary and trace gates | Phase 1 crossrepo tasks |
| Freshness separate from compilation currency | Knowledge Workflow | Agent API; Reconciliation | Phase 1 status gate | Phase 1 lifecycle tasks |
| FTS5 required, embedding optional | Product Vision | SQLite Schema; Runtime | Phase 1 no-embedding gate | Phase 1 search tasks |
| No Phase 4 | Roadmap; Design Authority | None | Roadmap consistency check | Governance only |

Every future task must add or update a row when it introduces a public capability, schema, phase gate, or architectural decision.

