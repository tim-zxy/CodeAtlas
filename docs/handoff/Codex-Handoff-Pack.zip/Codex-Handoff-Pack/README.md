# Codex Handoff Pack

This pack is the implementation authority for the local-first Engineering Intelligence and Knowledge Runtime designed in the source conversation.

Read in this order:

1. `CODEX_HANDOFF.md`
2. `PRODUCT_VISION.md`
3. `DESIGN_AUTHORITY.md`
4. `ARCHITECTURE.md`
5. `ROADMAP.md`
6. `PHASE_ACCEPTANCE.md`
7. `WORK_BREAKDOWN.md`
8. `IMPLEMENTATION_PROTOCOL.md`
9. Relevant files under `specs/` and `adr/`
10. `CURRENT_STATUS.md`

The formal roadmap contains Phase 0, Phase 0.5, Phase 1, Phase 2, and Phase 3. It intentionally contains no Phase 4.

The canonical flow naming is `ExecutionGraph -> RuntimeFlow -> BusinessFlow`.

