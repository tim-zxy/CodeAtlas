# Engineering Agent Instructions

This repository uses an agent-neutral Engineering Handoff Pack. These instructions apply to Codex, Claude Code, OpenCode, and any other Coding Agent or Implementation Agent working in this repository.

## Required reading before modifying code

Read these documents in order before making any code, schema, configuration, fixture, or build change:

1. `outputs/Engineering-Handoff-Pack/ENGINEERING_HANDOFF.md`
2. `outputs/Engineering-Handoff-Pack/CURRENT_STATUS.md`
3. `outputs/Engineering-Handoff-Pack/DESIGN_AUTHORITY.md`
4. `outputs/Engineering-Handoff-Pack/IMPLEMENTATION_PROTOCOL.md`
5. `outputs/Engineering-Handoff-Pack/ROADMAP.md`
6. The active phase sections in `outputs/Engineering-Handoff-Pack/WORK_BREAKDOWN.md` and `outputs/Engineering-Handoff-Pack/PHASE_ACCEPTANCE.md`
7. Every relevant ADR under `outputs/Engineering-Handoff-Pack/adr/`
8. Every relevant specification under `outputs/Engineering-Handoff-Pack/specs/`
9. `outputs/Engineering-Handoff-Pack/DESIGN_TRACEABILITY.md`

Do not rely on the original ChatGPT discussion or any unavailable conversation history. The repository documents are the implementation authority.

## Design governance

- FROZEN decisions must not be changed silently. Submit an ADR or Design Change Proposal and update all affected specs, acceptance gates, traceability, migrations, and fixtures before implementation.
- EVOLVABLE decisions may change only when Fixture or Evaluation results justify the change. Record the evidence and synchronize the controlling design documents and baselines.
- DEFERRED decisions are designed in their assigned phase. Do not introduce them as dependencies or scope in Phase 0, Phase 0.5, or Phase 1.

## Required invariants

- Preserve provider-independent Canonical IR.
- Keep SQLite authoritative and vector indexes derived and rebuildable.
- Keep LLM output candidate-only; only validated application workflows may publish canonical knowledge.
- Preserve AUTO updates for source/code/contract/ExecutionGraph/RuntimeFlow facts and MANUAL publication for semantic claims, Capability, BusinessFlow, architecture knowledge, and wiki projections.
- Use `ExecutionGraph -> RuntimeFlow -> BusinessFlow`; do not restore the retired flow identifier as a formal core model.
- Do not add a Phase 4 without a formally approved design.

## Task completion

Follow `IMPLEMENTATION_PROTOCOL.md`. Run the declared tests, Fixtures, Evaluation gates, failure/recovery checks, and architecture checks. Update `CURRENT_STATUS.md` after every completed task. A task is not complete without fresh reproducible evidence and traceability updates for changed contracts.

